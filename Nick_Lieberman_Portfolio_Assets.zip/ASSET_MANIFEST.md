# Nick Lieberman Portfolio Asset Manifest

These eleven files are the curated, approved public assets for the portfolio redesign. Copy the included `public/assets` directory into the repository without changing the directory structure.

## Loven

- `public/assets/loven/loven-create-batch.png`
  - Use for: Step 1, creating a batch.
  - Suggested alt text: "Loven form for creating a new batch of scheduled messages."
- `public/assets/loven/loven-envelope.png`
  - Use for: Recipient experience before opening a message.
  - Suggested alt text: "Loven recipient page showing a message waiting inside an envelope."
- `public/assets/loven/loven-message.png`
  - Use for: Revealed-message state.
  - Suggested alt text: "A personal message revealed in the Loven recipient experience."

The Nick and Dad copy in these screenshots is fictional demonstration content approved for public display.

## Lake Street Labs

- `public/assets/lake-street-labs/lake-street-guide.png`
  - Use for: Primary Lake Street Labs visual.
  - Suggested alt text: "Lake Street Labs website featuring its canker sore guide and tracker."
- `public/assets/lake-street-labs/lake-street-products.png`
  - Use for: Supporting product-selection visual.
  - Suggested alt text: "Lake Street Labs guide and tracker product selection screen."

The guide, tracker, covers, and product compositions belong to Nick and are approved for portfolio use. Do not add medical treatment claims.

## Cura Health at Berkeley

- `public/assets/cura/cura-glide-group.jpg`
  - Use for: Primary Cura photograph.
  - Suggested alt text: "Cura Health at Berkeley volunteers gathered outside Glide in San Francisco."
- `public/assets/cura/cura-clothing-sort.jpg`
  - Use for: Clothing-drive photograph.
  - Suggested alt text: "Cura Health at Berkeley members sorting donated clothing."
- `public/assets/cura/cura-project-open-hand.jpg`
  - Use for: Project Open Hand photograph.
  - Suggested alt text: "Cura Health at Berkeley volunteers at Project Open Hand."

No donation-flyer screenshots are included. Do not add any image that reveals a personal phone number.

## GCI General Contractors

- `public/assets/gci/gci-nick-booth.jpg`
  - Use for: GCI experience section.
  - Suggested alt text: "Nick Lieberman representing GCI General Contractors at an outreach booth."

## Marin Emergency Kits

- `public/assets/marin-emergency-kits/marin-kit-contents.jpg`
  - Use for: Supporting image; do not stretch it across the full viewport.
  - Suggested alt text: "Emergency supplies arranged beside a completed Marin Emergency Kit."
- `public/assets/marin-emergency-kits/marin-kit-delivery.jpg`
  - Use for: Primary delivery photograph.
  - Suggested alt text: "Two completed Marin Emergency Kits delivered to a local home."

## Curation and privacy notes

- Do not add any other task images merely because they were supplied.
- The social-media crop, screen-distorted GCI group image, duplicate Cura photos, Cura logo, donation-flyer screenshots, and redundant single-kit photo were intentionally excluded.
- Use deliberate crops, explicit aspect ratios, `object-fit`, descriptive alt text, and lazy loading below the fold.
- Do not expose browser tabs, private URLs, access tokens, or phone numbers.
